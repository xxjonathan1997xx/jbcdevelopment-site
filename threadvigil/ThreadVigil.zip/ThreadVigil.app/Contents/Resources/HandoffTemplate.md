# Continuation Handoff

## Objective
{{objective}}

## Current state
{{current_state}}

## Workspace
- Path: {{path}}
- Branch: {{branch}}
- Tool: {{tool}}

## Recent actions
{{recent_actions}}

## Blockers
{{blockers}}

## Next steps
{{next_steps}}

## Verification
{{verification}}

